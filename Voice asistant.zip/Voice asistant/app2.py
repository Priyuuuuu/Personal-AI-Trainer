import os
import streamlit as st
import speech_recognition as sr
import pyttsx3
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# Set the API key for Groq
os.environ['GROQ_API_KEY'] = "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"

# Initialize text-to-speech engine (pyttsx3)
engine = pyttsx3.init()
engine.setProperty('rate', 150)  # Set speaking rate

# Initialize Groq model (ChatGroq)
llm = ChatGroq(
    model="mixtral-8x7b-32768",  # Replace with your Groq model name
    temperature=0.7,
    max_tokens=100,
    timeout=30,
    max_retries=2,
)

# Set up a prompt for the assistant's conversation
template = """
You are a helpful assistant. Answer the user's question or carry out the task they request.
Human: {input}
AI:
"""

# Create the prompt template and LLMChain
prompt = PromptTemplate(input_variables=["input"], template=template)
llm_chain = LLMChain(prompt=prompt, llm=llm)

# Function to convert text to speech
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Function to recognize speech and convert to text
def recognize_audio(audio):
    recognizer = sr.Recognizer()
    try:
        text = recognizer.recognize_google(audio)
        return text
    except sr.UnknownValueError:
        return "Sorry, I didn't catch that."
    except sr.RequestError:
        return "There was an issue with the speech recognition service."

# Initialize Streamlit session state
if "conversation" not in st.session_state:
    st.session_state.conversation = []

if "listening" not in st.session_state:
    st.session_state.listening = False

# Streamlit interface
st.title("Personal AI Assistant")
st.write("Talk or type to your assistant for continuous conversation.")

# Input mode selection
input_mode = st.radio("Choose Input Mode", ["Text", "Voice"])

# Continuous conversation display
for chat in st.session_state.conversation:
    st.write(f"**You**: {chat['user']}")
    st.write(f"**AI**: {chat['ai']}")

# Handle text-based interaction
if input_mode == "Text":
    user_input = st.text_input("Enter your message:", "")
    if user_input:
        # Generate AI response
        ai_response = llm_chain.run(user_input)

        # Store conversation
        st.session_state.conversation.append({"user": user_input, "ai": ai_response})

        # Display and speak response
        st.write(f"**AI**: {ai_response}")
        speak(ai_response)

# Handle voice-based interaction
elif input_mode == "Voice":
    listen_button = st.button("Start Listening")
    if listen_button:
        st.write("Listening...")
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            recognizer.adjust_for_ambient_noise(source)
            audio = recognizer.listen(source)

        # Process the audio input
        user_input = recognize_audio(audio)
        st.write(f"**You**: {user_input}")

        if user_input:
            # Generate AI response
            ai_response = llm_chain.run(user_input)

            # Store conversation
            st.session_state.conversation.append({"user": user_input, "ai": ai_response})

            # Display and speak response
            st.write(f"**AI**: {ai_response}")
            speak(ai_response)
