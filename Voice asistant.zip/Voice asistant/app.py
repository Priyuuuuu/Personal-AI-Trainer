import os
import streamlit as st
import speech_recognition as sr
import pyttsx3
from langchain_groq import ChatGroq
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# Set the API key for Groq
os.environ['GROQ_API_KEY'] = "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"

# Initialize text-to-speech engine (pyttsx3)
engine = pyttsx3.init()

# Initialize Groq model (ChatGroq)
llm = ChatGroq(
    model="mixtral-8x7b-32768",  # Replace with your Groq model name
    temperature=0.7,
    max_tokens=100,
    timeout=30,
    max_retries=2,
)

# Set up a prompt for the assistant's conversation
template = """
You are a helpful assistant. Answer the user's question or carry out the task they request.
Human: {input}
AI:
"""

# Create the prompt template and LLMChain
prompt = PromptTemplate(input_variables=["input"], template=template)
llm_chain = LLMChain(prompt=prompt, llm=llm)

# Function to convert text to speech
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Function to recognize speech and convert to text
def listen(audio):
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)
        
    try:
        print("Recognizing...")
        text = recognizer.recognize_google(audio)  # Use Google's speech-to-text API
        print(f"You said: {text}")
        return text
    except sr.UnknownValueError:
        print("Sorry, I didn't understand that.")
        return None
    except sr.RequestError:
        print("Could not request results; check your internet connection.")
        return None

# Streamlit interface
st.title("AI Voice Assistant")

# Add an option for the user to input text or use voice
input_mode = st.radio("Choose Input Mode", ["Text", "Voice"])

# Text-based input mode
if input_mode == "Text":
    user_input = st.text_input("Enter your question or command:", "")
    if user_input:
        # Send the input to Groq AI via LangChain for a response
        response = llm_chain.run(user_input)
        # Output the AI's response
        st.write(f"AI: {response}")
        # Convert the response to speech and speak it out loud
        speak(response)

# Voice-based input mode
elif input_mode == "Voice":
    listen_button = st.button("Start Listening")
    recognize_button = st.button("stop Listening")

    if listen_button:
        st.write("Listening for your command...")
        # user_input = listen()
        recognizer = sr.Recognizer()
        with sr.Microphone() as source:
            print("Listening...")
            recognizer.adjust_for_ambient_noise(source)
            audio = recognizer.listen(source)
            st.session_state.audio = audio 
    
    if recognize_button:
        user_input = listen(st.session_state.audio)
        st.write("recognizing...")

        if user_input:
            # Send the input to Groq AI via LangChain for a response
            response = llm_chain.run(user_input)
            # Output the AI's response
            st.write(f"AI: {response}")
            # Convert the response to speech and speak it out loud
            speak(response)

        # Disable the button after listening to avoid continuous listening
        st.button("Stop Listening", disabled=True)
        
        # Re-enable the 'Start Listening' button to allow restarting listening again
        listen_button = st.button("Start Listening", disabled=False)
